class Parking_Structure:
    # data structure to hold parking structure data
    def __init__(self, structure):
        self.structure = structure
        self.permit = []

class Permit:
    # data structure to hold permit data
    def __init__(self, color="No Color", level=-1, spots=-1):
        self.color = color
        self.level = level
        self.spots = spots






